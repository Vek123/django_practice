menu = [{'name': 'НОВОСТИ', 'slug': 'mainSchool:news', 'position': 10},
        {'name': 'ОТЧЁТЫ', 'slug': 'mainSchool:reports', 'position': 2},
        {'name': 'ФОРМЫ', 'slug': 'mainSchool:forms', 'position': 3},
        ]
