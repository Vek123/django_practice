from mainSchool.utils import menu


def get_school_context(request):
    return {'nav_menu': menu}

